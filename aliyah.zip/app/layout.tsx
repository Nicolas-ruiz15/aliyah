import type { Metadata } from 'next';
import { Inter, Poppins } from 'next/font/google';
import './../styles/globals.css';
import { Providers } from '../components/providers/Providers';
import { Header } from '../components/layout/Header';
import { Footer } from '../components/layout/Footer';
import { Toaster } from '../components/ui/toast';

// Configuración de fuentes
const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
});

const poppins = Poppins({
  subsets: ['latin'],
  weight: ['300', '400', '500', '600', '700', '800'],
  variable: '--font-poppins',
  display: 'swap',
});

// Metadata de la aplicación
export const metadata: Metadata = {
  title: {
    default: 'Plataforma Aliá Sionista | עלייה לישראל',
    template: '%s | Plataforma Aliá Sionista'
  },
  description: 'Plataforma integral para judíos ortodoxos que desean hacer aliá a Israel. Incluye formularios de registro, educación halájica, noticias de Israel y apoyo completo para el proceso de inmigración.',
  keywords: [
    'aliá', 'aliyah', 'Israel', 'inmigración', 'judío ortodoxo', 'sionista',
    'halajá', 'judaísmo', 'educación judía', 'noticias Israel', 'bet din',
    'conversión judía', 'vida judía', 'tierra de Israel', 'עלייה', 'ישראל'
  ],
  authors: [{ name: 'Plataforma Aliá Sionista' }],
  creator: 'Plataforma Aliá Sionista',
  publisher: 'Plataforma Aliá Sionista',
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  openGraph: {
    type: 'website',
    locale: 'es_ES',
    alternateLocale: 'he_IL',
    url: process.env.NEXTAUTH_URL || 'https://tu-dominio.com',
    siteName: 'Plataforma Aliá Sionista',
    title: 'Plataforma Aliá Sionista | עלייה לישראל',
    description: 'Tu camino hacia la aliá comienza aquí. Plataforma integral para judíos ortodoxos sionistas.',
    images: [
      {
        url: '/images/og-image.jpg',
        width: 1200,
        height: 630,
        alt: 'Plataforma Aliá Sionista - Tu camino hacia Israel',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Plataforma Aliá Sionista | עלייה לישראל',
    description: 'Tu camino hacia la aliá comienza aquí. Plataforma integral para judíos ortodoxos sionistas.',
    images: ['/images/twitter-image.jpg'],
    creator: '@PlataformaAlia',
  },
  icons: {
    icon: [
      { url: '/favicon.ico' },
      { url: '/icon-16x16.png', sizes: '16x16', type: 'image/png' },
      { url: '/icon-32x32.png', sizes: '32x32', type: 'image/png' },
    ],
    apple: [
      { url: '/apple-touch-icon.png' },
    ],
    other: [
      {
        rel: 'mask-icon',
        url: '/safari-pinned-tab.svg',
        color: '#0033CC',
      },
    ],
  },
  manifest: '/site.webmanifest',
  verification: {
    google: 'tu-codigo-de-verificacion-google',
  },
  category: 'education',
  classification: 'Jewish Education and Immigration Platform',
  other: {
    'theme-color': '#0033CC',
    'msapplication-TileColor': '#0033CC',
    'msapplication-config': '/browserconfig.xml',
  },
};

// Layout principal de la aplicación
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html 
      lang="es" 
      className={`${inter.variable} ${poppins.variable}`}
      suppressHydrationWarning
    >
      <head>
        {/* Preconectar a dominios externos para mejor rendimiento */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        
        {/* DNS prefetch para servicios externos */}
        <link rel="dns-prefetch" href="//timesofisrael.com" />
        <link rel="dns-prefetch" href="//now14.co.il" />
        <link rel="dns-prefetch" href="//jpost.com" />
        
        {/* Meta tags adicionales para SEO */}
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="format-detection" content="telephone=no" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        
        {/* Schema.org markup para SEO */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              '@context': 'https://schema.org',
              '@type': 'EducationalOrganization',
              name: 'Plataforma Aliá Sionista',
              alternateName: 'עלייה לישראל',
              url: process.env.NEXTAUTH_URL || 'https://tu-dominio.com',
              logo: `${process.env.NEXTAUTH_URL || 'https://tu-dominio.com'}/images/logo.png`,
              description: 'Plataforma integral para judíos ortodoxos que desean hacer aliá a Israel',
              educationalCredentialAwarded: 'Certificación en Halajá',
              hasCredential: 'Educación Judía Ortodoxa',
              audience: {
                '@type': 'Audience',
                audienceType: 'Judíos Ortodoxos Sionistas'
              },
              contactPoint: {
                '@type': 'ContactPoint',
                contactType: 'customer service',
                email: 'info@tu-dominio.com',
                availableLanguage: ['Spanish', 'Hebrew']
              },
              sameAs: [
                'https://facebook.com/PlataformaAlia',
                'https://twitter.com/PlataformaAlia',
                'https://instagram.com/PlataformaAlia'
              ]
            })
          }}
        />
      </head>
      
      <body className={`
        min-h-screen 
        bg-gradient-to-br 
        from-tallit-white 
        via-white 
        to-blue-50/30 
        font-sans 
        antialiased
      `}>
        <Providers>
          {/* Estructura principal de la página */}
          <div className="flex flex-col min-h-screen">
            {/* Header con navegación */}
            <Header />
            
            {/* Contenido principal */}
            <main className="flex-1 relative">
              {/* Patrón de fondo sutil */}
              <div className="absolute inset-0 opacity-5 pointer-events-none">
                <div className="absolute inset-0 bg-repeat" style={{
                  backgroundImage: "url('data:image/svg+xml,%3Csvg width=\"60\" height=\"60\" viewBox=\"0 0 60 60\" xmlns=\"http://www.w3.org/2000/svg\"%3E%3Cg fill=\"none\" fill-rule=\"evenodd\"%3E%3Cg fill=\"%230033CC\" fill-opacity=\"0.1\"%3E%3Cpath d=\"M30 30l15-15v30l-15-15zm-15 15l15-15H0l15 15z\"/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')",
                  backgroundSize: '60px 60px'
                }} />
              </div>
              
              {/* Contenido de la página */}
              <div className="relative z-10">
                {children}
              </div>
            </main>
            
            {/* Footer */}
            <Footer />
          </div>
          
          {/* Sistema de notificaciones */}
          <Toaster />
          
          {/* Componente de accesibilidad para lectores de pantalla */}
          <div id="skip-nav" className="sr-only">
            <a
              href="#main-content"
              className="fixed top-4 left-4 z-50 bg-primary text-primary-foreground px-4 py-2 rounded-md focus:not-sr-only"
            >
              Saltar al contenido principal
            </a>
          </div>
        </Providers>
        
        {/* Scripts para analytics (solo en producción) */}
        {process.env.NODE_ENV === 'production' && (
          <>
            {/* Google Analytics */}
            {process.env.NEXT_PUBLIC_GA_ID && (
              <>
                <script
                  async
                  src={`https://www.googletagmanager.com/gtag/js?id=${process.env.NEXT_PUBLIC_GA_ID}`}
                />
                <script
                  dangerouslySetInnerHTML={{
                    __html: `
                      window.dataLayer = window.dataLayer || [];
                      function gtag(){dataLayer.push(arguments);}
                      gtag('js', new Date());
                      gtag('config', '${process.env.NEXT_PUBLIC_GA_ID}');
                    `,
                  }}
                />
              </>
            )}
            
            {/* Microsoft Clarity (opcional) */}
            {process.env.NEXT_PUBLIC_CLARITY_ID && (
              <script
                dangerouslySetInnerHTML={{
                  __html: `
                    (function(c,l,a,r,i,t,y){
                        c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
                        t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
                        y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
                    })(window, document, "clarity", "script", "${process.env.NEXT_PUBLIC_CLARITY_ID}");
                  `,
                }}
              />
            )}
          </>
        )}
      </body>
    </html>
  );
}

// Configuración de runtime para Plesk
export const runtime = 'nodejs';

