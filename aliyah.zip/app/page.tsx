import React from 'react';
import Link from 'next/link';
import { 
  ArrowRight, 
  BookOpen, 
  Users, 
  Globe, 
  Shield, 
  Newspaper,
  CheckCircle,
  Star,
  Heart,
  MapPin
} from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';

export default function HomePage() {
  const features = [
    {
      icon: Users,
      title: 'Registro Personalizado',
      description: 'Formulario inteligente que se adapta a tu situación judía y familiar específica.',
      color: 'text-tekhelet-600'
    },
    {
      icon: BookOpen,
      title: 'Educación Halájica',
      description: 'Sistema gamificado para aprender halajá con progresión por niveles y certificados.',
      color: 'text-israel-blue-600'
    },
    {
      icon: Newspaper,
      title: 'Noticias de Israel',
      description: 'Agregación automática de noticias israelíes con traducción al español en tiempo real.',
      color: 'text-gold-accent-600'
    },
    {
      icon: Shield,
      title: 'Datos Seguros',
      description: 'Cifrado extremo a extremo para proteger toda tu información personal y documentos.',
      color: 'text-green-600'
    },
  ];

  const steps = [
    {
      number: '01',
      title: 'Registro',
      description: 'Completa tu perfil con información detallada sobre tu situación judía y motivación para la aliá.'
    },
    {
      number: '02',
      title: 'Educación',
      description: 'Estudia halajá através de nuestro sistema interactivo y obtén certificaciones por niveles.'
    },
    {
      number: '03',
      title: 'Preparación',
      description: 'Mantente informado con noticias de Israel y conecta con la comunidad de futuros olim.'
    },
    {
      number: '04',
      title: 'Aliá',
      description: 'Recibe apoyo personalizado para completar tu proceso de inmigración a Israel.'
    },
  ];

  const testimonials = [
    {
      name: 'David Cohen',
      location: 'Buenos Aires → Jerusalem',
      quote: 'La plataforma me ayudó a entender mejor la halajá y me preparó espiritualmente para la aliá.',
      rating: 5
    },
    {
      name: 'Sarah Goldberg',
      location: 'México → Tel Aviv',
      quote: 'El sistema de noticias traducidas me mantuvo conectada con Israel durante mi proceso.',
      rating: 5
    },
    {
      name: 'Rabbi Moshe Levy',
      location: 'Madrid → Bnei Brak',
      quote: 'Excelente recurso para la comunidad ortodoxa. Muy recomendado para preparar la aliá.',
      rating: 5
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 md:py-32 overflow-hidden">
        {/* Fondo con patrón */}
        <div className="absolute inset-0 bg-gradient-to-br from-tekhelet-50 via-white to-israel-blue-50"></div>
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0 bg-repeat" style={{
            backgroundImage: "url('data:image/svg+xml,%3Csvg width=\"100\" height=\"100\" viewBox=\"0 0 100 100\" xmlns=\"http://www.w3.org/2000/svg\"%3E%3Cg fill=\"none\" fill-rule=\"evenodd\"%3E%3Cg fill=\"%230033CC\" fill-opacity=\"0.1\"%3E%3Cpath d=\"M50 50l25-25v50l-25-25zm-25 25l25-25H0l25 25z\"/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')",
            backgroundSize: '100px 100px'
          }} />
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            {/* Badge */}
            <div className="inline-flex items-center px-4 py-2 bg-gradient-gold rounded-full text-sm font-medium text-gray-900 mb-6">
              <Star className="h-4 w-4 mr-2" />
              Plataforma Oficial para Aliá Judía Ortodoxa
            </div>

            {/* Título principal */}
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Tu camino hacia
              <span className="block bg-gradient-israel bg-clip-text text-transparent">
                Eretz Israel
              </span>
              <span className="block text-2xl md:text-3xl hebrew font-normal mt-2 text-tekhelet-700">
                דרכך לארץ ישראל
              </span>
            </h1>

            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
              Plataforma integral diseñada específicamente para judíos ortodoxos sionistas. 
              Combina educación halájica, noticias de Israel y apoyo personalizado para 
              hacer realidad tu sueño de la aliá.
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/auth/register">
                <Button size="lg" variant="orthodox" className="text-lg px-8">
                  Comenzar mi Aliá
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link href="/noticias">
                <Button size="lg" variant="outline" className="text-lg px-8">
                  Ver Noticias de Israel
                  <Globe className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </div>

            {/* Stats */}
            <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-tekhelet-700">500+</div>
                <div className="text-sm text-gray-600">Familias registradas</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-israel-blue-700">50+</div>
                <div className="text-sm text-gray-600">Lecciones de Halajá</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-gold-accent-600">24/7</div>
                <div className="text-sm text-gray-600">Noticias actualizadas</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600">100%</div>
                <div className="text-sm text-gray-600">Datos seguros</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Todo lo que necesitas para tu Aliá
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Herramientas diseñadas específicamente para la comunidad judía ortodoxa sionista
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature) => (
              <Card key={feature.title} variant="orthodox" className="text-center group hover:scale-105 transition-transform">
                <CardHeader>
                  <div className="mx-auto mb-4">
                    <div className="h-16 w-16 bg-gradient-to-br from-tekhelet-100 to-israel-blue-100 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
                      <feature.icon className={`h-8 w-8 ${feature.color}`} />
                    </div>
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-tekhelet-50/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Cómo funciona
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Cuatro pasos simples hacia tu nueva vida en Israel
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {steps.map((step, index) => (
                <div key={step.number} className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <div className="h-12 w-12 bg-gradient-israel rounded-xl flex items-center justify-center text-white font-bold text-lg">
                      {step.number}
                    </div>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      {step.title}
                    </h3>
                    <p className="text-gray-600">
                      {step.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Historias de éxito
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Conoce a familias que ya cumplieron su sueño de la aliá
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {testimonials.map((testimonial) => (
              <Card key={testimonial.name} variant="featured" className="text-center">
                <CardHeader>
                  <div className="flex justify-center mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 text-gold-accent-500 fill-current" />
                    ))}
                  </div>
                  <CardDescription className="text-base italic mb-4">
                    "{testimonial.quote}"
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="font-semibold text-gray-900">{testimonial.name}</div>
                  <div className="text-sm text-gray-600 flex items-center justify-center mt-1">
                    <MapPin className="h-4 w-4 mr-1" />
                    {testimonial.location}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-20 bg-gradient-israel text-white">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-3xl mx-auto">
            <Heart className="h-16 w-16 text-gold-accent-400 mx-auto mb-6" />
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              ¿Listo para hacer Aliá?
            </h2>
            <p className="text-xl opacity-90 mb-8">
              Únete a miles de familias judías ortodoxas que ya comenzaron su camino hacia 
              la Tierra Prometida. Tu hogar en Israel te está esperando.
            </p>
            <div className="space-y-4 sm:space-y-0 sm:space-x-4 sm:flex sm:justify-center">
              <Link href="/auth/register">
                <Button size="lg" variant="gold" className="text-lg px-8">
                  Comenzar ahora
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link href="/contacto">
                <Button size="lg" variant="outline" className="text-lg px-8 border-white text-white hover:bg-white hover:text-gray-900">
                  Hablar con un asesor
                </Button>
              </Link>
            </div>
            <p className="text-sm opacity-75 mt-6 hebrew">
              עם ישראל חי • בית ישראל בארץ ישראל
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}