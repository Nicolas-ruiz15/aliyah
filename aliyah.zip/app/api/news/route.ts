import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '../../../lib/prisma';

// Schema de validación para filtros de noticias
const newsFiltersSchema = z.object({
  page: z.coerce.number().min(1).default(1),
  limit: z.coerce.number().min(1).max(50).default(20),
  search: z.string().optional(),
  sourceIds: z.array(z.string()).optional(),
  categories: z.array(z.string()).optional(),
  isFeatured: z.coerce.boolean().optional(),
  dateFrom: z.string().optional(),
  dateTo: z.string().optional(),
});

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    
    // Convertir parámetros de URL a objeto
    const params = {
      page: searchParams.get('page'),
      limit: searchParams.get('limit'),
      search: searchParams.get('search'),
      sourceIds: searchParams.getAll('sourceIds'),
      categories: searchParams.getAll('categories'),
      isFeatured: searchParams.get('isFeatured'),
      dateFrom: searchParams.get('dateFrom'),
      dateTo: searchParams.get('dateTo'),
    };

    // Limpiar parámetros vacíos
    const cleanParams = Object.fromEntries(
      Object.entries(params).filter(([_, value]) => {
        if (Array.isArray(value)) return value.length > 0;
        return value !== null && value !== '';
      })
    );

    const validatedParams = newsFiltersSchema.parse(cleanParams);

    // Construir filtros de Prisma
    const where: any = {
      isActive: true,
    };

    if (validatedParams.search) {
      where.OR = [
        {
          titleTranslated: {
            contains: validatedParams.search,
            mode: 'insensitive',
          },
        },
        {
          summaryTranslated: {
            contains: validatedParams.search,
            mode: 'insensitive',
          },
        },
        {
          title: {
            contains: validatedParams.search,
            mode: 'insensitive',
          },
        },
      ];
    }

    if (validatedParams.sourceIds && validatedParams.sourceIds.length > 0) {
      where.sourceId = {
        in: validatedParams.sourceIds,
      };
    }

    if (validatedParams.categories && validatedParams.categories.length > 0) {
      where.category = {
        in: validatedParams.categories,
      };
    }

    if (validatedParams.isFeatured !== undefined) {
      where.isFeatured = validatedParams.isFeatured;
    }

    if (validatedParams.dateFrom || validatedParams.dateTo) {
      where.publishedAt = {};
      if (validatedParams.dateFrom) {
        where.publishedAt.gte = new Date(validatedParams.dateFrom);
      }
      if (validatedParams.dateTo) {
        where.publishedAt.lte = new Date(validatedParams.dateTo);
      }
    }

    // Calcular offset para paginación
    const offset = (validatedParams.page - 1) * validatedParams.limit;

    // Obtener artículos
    const [articles, totalCount] = await Promise.all([
      prisma.article.findMany({
        where,
        include: {
          source: {
            select: {
              id: true,
              name: true,
              nameHebrew: true,
              url: true,
            },
          },
        },
        orderBy: [
          { isFeatured: 'desc' },
          { publishedAt: 'desc' },
        ],
        skip: offset,
        take: validatedParams.limit,
      }),
      prisma.article.count({ where }),
    ]);

    // Calcular metadatos de paginación
    const totalPages = Math.ceil(totalCount / validatedParams.limit);
    const hasNext = validatedParams.page < totalPages;
    const hasPrev = validatedParams.page > 1;

    return NextResponse.json({
      success: true,
      data: {
        articles,
        pagination: {
          current: validatedParams.page,
          total: totalPages,
          limit: validatedParams.limit,
          totalCount,
          hasNext,
          hasPrev,
        },
      },
    });

  } catch (error) {
    console.error('Error obteniendo noticias:', error);

    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { 
          error: 'Parámetros inválidos', 
          details: error.errors 
        },
        { status: 400 }
      );
    }

    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}

// Endpoint para obtener fuentes de noticias
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action } = body;

    if (action === 'get_sources') {
      const sources = await prisma.newsSource.findMany({
        where: {
          isActive: true,
        },
        select: {
          id: true,
          name: true,
          nameHebrew: true,
          url: true,
          type: true,
          lastFetched: true,
          _count: {
            select: {
              articles: {
                where: {
                  isActive: true,
                },
              },
            },
          },
        },
        orderBy: {
          name: 'asc',
        },
      });

      return NextResponse.json({
        success: true,
        data: sources,
      });
    }

    if (action === 'get_categories') {
      const categories = await prisma.article.findMany({
        where: {
          isActive: true,
          category: {
            not: null,
          },
        },
        select: {
          category: true,
        },
        distinct: ['category'],
        orderBy: {
          category: 'asc',
        },
      });

      const categoryList = categories
        .map(item => item.category)
        .filter(Boolean) as string[];

      return NextResponse.json({
        success: true,
        data: categoryList,
      });
    }

    if (action === 'get_stats') {
      const [
        totalArticles,
        translatedArticles,
        featuredArticles,
        sourcesCount,
        todayArticles,
      ] = await Promise.all([
        prisma.article.count({
          where: { isActive: true },
        }),
        prisma.article.count({
          where: { 
            isActive: true,
            isTranslated: true,
          },
        }),
        prisma.article.count({
          where: { 
            isActive: true,
            isFeatured: true,
          },
        }),
        prisma.newsSource.count({
          where: { isActive: true },
        }),
        prisma.article.count({
          where: {
            isActive: true,
            createdAt: {
              gte: new Date(new Date().setHours(0, 0, 0, 0)),
            },
          },
        }),
      ]);

      return NextResponse.json({
        success: true,
        data: {
          totalArticles,
          translatedArticles,
          featuredArticles,
          sourcesCount,
          todayArticles,
          translationRate: totalArticles > 0 
            ? Math.round((translatedArticles / totalArticles) * 100) 
            : 0,
        },
      });
    }

    return NextResponse.json(
      { error: 'Acción no válida' },
      { status: 400 }
    );

  } catch (error) {
    console.error('Error en endpoint POST de noticias:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}