'use client';

import React from 'react';
import Link from 'next/link';
import { 
  BookOpen, 
  Newspaper, 
  User, 
  TrendingUp, 
  Calendar,
  MessageCircle,
  Award,
  MapPin,
  Clock,
  CheckCircle,
  AlertTriangle,
  Star
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Progress } from '../../components/ui/progress';
import { useAuth } from '../../components/providers/AuthProvider';
import { useTranslation } from '../../components/providers/LanguageProvider';

export default function DashboardPage() {
  const { user } = useAuth();
  const { t } = useTranslation();

  // Mock data - esto vendría de APIs reales
  const stats = {
    quizProgress: 65,
    completedQuizzes: 8,
    totalQuizzes: 12,
    newsRead: 45,
    daysActive: 28,
    currentLevel: 'Intermedio',
  };

  const recentActivities = [
    {
      id: 1,
      type: 'quiz',
      title: 'Kashrut Básico',
      description: 'Completado con 95% de acierto',
      time: '2 horas',
      icon: BookOpen,
      color: 'text-green-600',
    },
    {
      id: 2,
      type: 'news',
      title: 'Noticias de Israel',
      description: 'Leídos 5 artículos nuevos',
      time: '1 día',
      icon: Newspaper,
      color: 'text-blue-600',
    },
    {
      id: 3,
      type: 'profile',
      title: 'Perfil actualizado',
      description: 'Documentos subidos correctamente',
      time: '3 días',
      icon: User,
      color: 'text-purple-600',
    },
  ];

  const upcomingTasks = [
    {
      id: 1,
      title: 'Completar módulo de Shabat',
      description: 'Faltan 4 lecciones para terminar',
      priority: 'high',
      dueDate: '2 días',
    },
    {
      id: 2,
      title: 'Actualizar documentos',
      description: 'Subir certificado de estudios',
      priority: 'medium',
      dueDate: '1 semana',
    },
    {
      id: 3,
      title: 'Revisar noticias',
      description: 'Nuevos artículos sobre inmigración',
      priority: 'low',
      dueDate: '3 días',
    },
  ];

  const quickActions = [
    {
      title: 'Continuar Estudios',
      description: 'Siguiente lección: Halajá de Tefilá',
      href: '/estudiar',
      icon: BookOpen,
      color: 'bg-tekhelet-600',
    },
    {
      title: 'Leer Noticias',
      description: '12 artículos nuevos de Israel',
      href: '/noticias',
      icon: Newspaper,
      color: 'bg-israel-blue-600',
    },
    {
      title: 'Mi Perfil',
      description: 'Actualizar información personal',
      href: '/dashboard/perfil',
      icon: User,
      color: 'bg-gold-accent-600',
    },
    {
      title: 'Progreso',
      description: 'Ver mis logros y certificados',
      href: '/dashboard/progreso',
      icon: TrendingUp,
      color: 'bg-green-600',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-tallit-white via-white to-blue-50/30">
      <div className="container mx-auto px-4 py-8">
        {/* Header de bienvenida */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
				Shalom, {user?.profile?.firstNameEncrypted || user?.email?.split('@')[0]}!              </h1>
              <p className="text-gray-600">
                Continúa tu camino hacia Eretz Israel
              </p>
              <p className="text-sm hebrew text-tekhelet-700 mt-1">
                המשך את דרכך לארץ ישראל
              </p>
            </div>
            <div className="text-right">
              <div className="text-sm text-gray-500">Nivel actual</div>
              <div className="text-2xl font-bold text-tekhelet-700">
                {stats.currentLevel}
              </div>
            </div>
          </div>

          {/* Barra de progreso general */}
          <Card variant="featured">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">
                    Progreso General de Aliá
                  </h3>
                  <p className="text-sm text-gray-600">
                    {stats.completedQuizzes} de {stats.totalQuizzes} módulos completados
                  </p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-tekhelet-600">
                    {stats.quizProgress}%
                  </div>
                  <div className="text-xs text-gray-500">Completado</div>
                </div>
              </div>
              <Progress value={stats.quizProgress} className="h-3" />
            </CardContent>
          </Card>
        </div>

        {/* Grid principal */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Columna izquierda - Acciones rápidas y estadísticas */}
          <div className="lg:col-span-2 space-y-8">
            {/* Acciones rápidas */}
            <div>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">
                Acciones Rápidas
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {quickActions.map((action) => (
                  <Link key={action.title} href={action.href}>
                    <Card className="hover:scale-105 transition-transform cursor-pointer group">
                      <CardContent className="p-6">
                        <div className="flex items-center space-x-4">
                          <div className={`h-12 w-12 rounded-xl ${action.color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                            <action.icon className="h-6 w-6 text-white" />
                          </div>
                          <div className="flex-1">
                            <h3 className="font-semibold text-gray-900">
                              {action.title}
                            </h3>
                            <p className="text-sm text-gray-600">
                              {action.description}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            </div>

            {/* Estadísticas */}
            <div>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">
                Estadísticas de Actividad
              </h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Card variant="orthodox">
                  <CardContent className="p-4 text-center">
                    <BookOpen className="h-8 w-8 text-tekhelet-600 mx-auto mb-2" />
                    <div className="text-2xl font-bold text-gray-900">
                      {stats.completedQuizzes}
                    </div>
                    <div className="text-xs text-gray-600">Quiz completados</div>
                  </CardContent>
                </Card>

                <Card variant="orthodox">
                  <CardContent className="p-4 text-center">
                    <Newspaper className="h-8 w-8 text-israel-blue-600 mx-auto mb-2" />
                    <div className="text-2xl font-bold text-gray-900">
                      {stats.newsRead}
                    </div>
                    <div className="text-xs text-gray-600">Noticias leídas</div>
                  </CardContent>
                </Card>

                <Card variant="orthodox">
                  <CardContent className="p-4 text-center">
                    <Calendar className="h-8 w-8 text-gold-accent-600 mx-auto mb-2" />
                    <div className="text-2xl font-bold text-gray-900">
                      {stats.daysActive}
                    </div>
                    <div className="text-xs text-gray-600">Días activo</div>
                  </CardContent>
                </Card>

                <Card variant="orthodox">
                  <CardContent className="p-4 text-center">
                    <Award className="h-8 w-8 text-green-600 mx-auto mb-2" />
                    <div className="text-2xl font-bold text-gray-900">
                      {Math.floor(stats.quizProgress / 20)}
                    </div>
                    <div className="text-xs text-gray-600">Certificados</div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Actividad reciente */}
            <div>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">
                Actividad Reciente
              </h2>
              <Card>
                <CardContent className="p-0">
                  <div className="divide-y divide-gray-100">
                    {recentActivities.map((activity) => (
                      <div key={activity.id} className="p-4 hover:bg-gray-50 transition-colors">
                        <div className="flex items-center space-x-4">
                          <div className="h-10 w-10 bg-gray-100 rounded-lg flex items-center justify-center">
                            <activity.icon className={`h-5 w-5 ${activity.color}`} />
                          </div>
                          <div className="flex-1">
                            <h4 className="font-medium text-gray-900">
                              {activity.title}
                            </h4>
                            <p className="text-sm text-gray-600">
                              {activity.description}
                            </p>
                          </div>
                          <div className="text-sm text-gray-500">
                            Hace {activity.time}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Columna derecha - Sidebar */}
          <div className="space-y-6">
            {/* Próximas tareas */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Clock className="h-5 w-5" />
                  <span>Próximas Tareas</span>
                </CardTitle>
                <CardDescription>
                  Completa estas actividades para avanzar
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {upcomingTasks.map((task) => (
                  <div key={task.id} className="border-l-4 border-l-tekhelet-500 pl-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900 text-sm">
                          {task.title}
                        </h4>
                        <p className="text-xs text-gray-600 mt-1">
                          {task.description}
                        </p>
                      </div>
                      <div className={`text-xs px-2 py-1 rounded-full ${
                        task.priority === 'high' ? 'bg-red-100 text-red-700' :
                        task.priority === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                        'bg-gray-100 text-gray-700'
                      }`}>
                        {task.dueDate}
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Noticias destacadas */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Newspaper className="h-5 w-5" />
                  <span>Noticias Destacadas</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="border-b border-gray-100 pb-3">
                  <h4 className="text-sm font-medium text-gray-900">
                    Nueva ley de inmigración aprobada
                  </h4>
                  <p className="text-xs text-gray-600 mt-1">
                    Facilita el proceso para familias judías ortodoxas
                  </p>
                  <div className="text-xs text-gray-500 mt-2">Hace 2 horas</div>
                </div>
                
                <div className="border-b border-gray-100 pb-3">
                  <h4 className="text-sm font-medium text-gray-900">
                    Nuevos programas de integración
                  </h4>
                  <p className="text-xs text-gray-600 mt-1">
                    Kursos de hebreo gratuitos en Jerusalem
                  </p>
                  <div className="text-xs text-gray-500 mt-2">Hace 5 horas</div>
                </div>

                <Button variant="outline" size="sm" className="w-full">
                  Ver todas las noticias
                </Button>
              </CardContent>
            </Card>

            {/* Motivación del día */}
            <Card variant="featured">
              <CardContent className="p-6 text-center">
                <Star className="h-8 w-8 text-gold-accent-500 mx-auto mb-3" />
                <h3 className="font-semibold text-gray-900 mb-2">
                  Pensamiento del Día
                </h3>
                <blockquote className="text-sm italic text-gray-600 mb-3">
                  "Quien vive en Eretz Israel vive sin pecado"
                </blockquote>
                <p className="text-xs text-gray-500">- Talmud, Ketubot 111a</p>
                <p className="text-xs hebrew text-tekhelet-600 mt-2">
                  הדר בארץ ישראל דומה כמי שיש לו אלוה
                </p>
              </CardContent>
            </Card>

            {/* Soporte */}
            <Card>
              <CardContent className="p-6 text-center">
                <MessageCircle className="h-8 w-8 text-tekhelet-600 mx-auto mb-3" />
                <h3 className="font-semibold text-gray-900 mb-2">
                  ¿Necesitas ayuda?
                </h3>
                <p className="text-sm text-gray-600 mb-4">
                  Nuestro equipo está aquí para apoyarte en tu camino hacia la aliá
                </p>
                <Button variant="outline" size="sm" className="w-full">
                  Contactar Soporte
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}