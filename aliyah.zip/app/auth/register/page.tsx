'use client';

import React from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { RegistrationForm } from '../../../components/forms/RegistrationForm';
import { Heart, Star, Globe, Shield } from 'lucide-react';

export default function RegisterPage() {
  const router = useRouter();

  // ✅ Cambio: Usar any o el tipo específico que devuelve el formulario
  const handleRegistrationSuccess = (data: any) => {
    // Redirigir al dashboard o página de verificación
    router.push('/auth/verify-request?email=' + encodeURIComponent(data.email));
  };

  const benefits = [
    {
      icon: Heart,
      title: 'Tu camino personal',
      description: 'Registro adaptado a tu situación judía específica'
    },
    {
      icon: Star,
      title: 'Educación halájica',
      description: 'Aprende y certifica tu conocimiento'
    },
    {
      icon: Globe,
      title: 'Noticias de Israel',
      description: 'Mantente conectado con Eretz Israel'
    },
    {
      icon: Shield,
      title: 'Datos seguros',
      description: 'Máxima protección y confidencialidad'
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-tallit-white via-white to-blue-50/30">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Únete a la Plataforma Aliá
          </h1>
          <p className="text-xl text-gray-600 mb-2">
            Tu camino hacia Eretz Israel comienza aquí
          </p>
          <p className="text-lg hebrew text-tekhelet-700 font-medium">
            הדרכך לארץ ישראל מתחילה כאן
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 mb-12">
          {/* Sidebar con beneficios */}
          <div className="lg:col-span-1">
            <div className="sticky top-8 space-y-6">
              <div className="bg-white rounded-xl shadow-soft p-6 border border-tekhelet-100">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">
                  ¿Por qué registrarse?
                </h3>
                <div className="space-y-4">
                  {benefits.map((benefit) => (
                    <div key={benefit.title} className="flex items-start space-x-3">
                      <div className="h-8 w-8 bg-tekhelet-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <benefit.icon className="h-4 w-4 text-tekhelet-600" />
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-gray-900">
                          {benefit.title}
                        </h4>
                        <p className="text-xs text-gray-600">
                          {benefit.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Stats */}
              <div className="bg-gradient-israel rounded-xl p-6 text-white">
                <h3 className="text-lg font-semibold mb-4">
                  Únete a nuestra comunidad
                </h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-blue-100">Familias registradas:</span>
                    <span className="font-bold">500+</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-blue-100">Aliyot completadas:</span>
                    <span className="font-bold">150+</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-blue-100">Países de origen:</span>
                    <span className="font-bold">25+</span>
                  </div>
                </div>
              </div>

              {/* Login link */}
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600 mb-2">
                  ¿Ya tienes cuenta?
                </p>
                <Link 
                  href="/auth/login"
                  className="text-tekhelet-600 hover:text-tekhelet-700 font-medium text-sm"
                >
                  Iniciar sesión
                </Link>
              </div>
            </div>
          </div>

          {/* Formulario principal */}
          <div className="lg:col-span-3">
            <RegistrationForm onSuccess={handleRegistrationSuccess} />
          </div>
        </div>

        {/* Footer de la página */}
        <div className="text-center text-sm text-gray-500 space-y-2">
          <p>
            Al registrarte, aceptas nuestros{' '}
            <Link href="/terminos" className="text-tekhelet-600 hover:underline">
              Términos de Servicio
            </Link>{' '}
            y{' '}
            <Link href="/privacidad" className="text-tekhelet-600 hover:underline">
              Política de Privacidad
            </Link>
          </p>
          <p className="hebrew text-xs">
            עם ישראל חי • בית ישראל בארץ ישראל
          </p>
        </div>
      </div>
    </div>
  );
}