'use client';

import React, { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { 
  BookOpen, 
  Play, 
  Clock, 
  CheckCircle,
  Star,
  ArrowLeft,
  Trophy,
  Target,
  BarChart3,
  AlertCircle,
  Award
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../../components/ui/card';
import { Button } from '../../../components/ui/button';
import { QuizComponent } from '../../../components/quiz/QuizComponent';
import { useAuth } from '../../../components/providers/AuthProvider';
import { useToast } from '../../../components/providers/ToastProvider';
import { cn } from '../../../lib/utils';
import type { QuizTopicWithQuestions, QuizResult, UserProgress } from '../../../types/global';

export default function QuizTopicPage() {
  const params = useParams();
  const router = useRouter();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [topic, setTopic] = useState<QuizTopicWithQuestions | null>(null);
  const [userProgress, setUserProgress] = useState<UserProgress | null>(null);
  const [loading, setLoading] = useState(true);
  const [showQuiz, setShowQuiz] = useState(false);
  const [previousAttempts, setPreviousAttempts] = useState<any[]>([]);

  const topicId = params.id as string;

  // Mock data - en la implementación real vendría de la API
  const mockTopic: QuizTopicWithQuestions = {
    id: topicId,
    title: 'Kashrut Básico',
    titleHebrew: 'כשרות בסיסית',
    description: 'Aprende las leyes dietéticas judías fundamentales: separación de carne y leche, animales permitidos y prohibidos, y supervisión rabínica.',
    level: 1,
    orderIndex: 2,
    isActive: true,
    requiredScore: 80,
    createdAt: new Date(),
    updatedAt: new Date(),
    questions: [
      {
        id: '1',
        topicId,
        questionText: '¿Cuál es el tiempo mínimo que se debe esperar entre comer carne y productos lácteos según la halajá ashkenazí?',
        explanation: 'Según la tradición ashkenazí, se debe esperar 6 horas entre comer carne y lácteos para permitir la digestión completa y evitar mezclar sabores.',
        difficulty: 2,
        orderIndex: 1,
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date(),
        answers: [
          {
            id: '1a',
            questionId: '1',
            answerText: '1 hora',
            isCorrect: false,
            orderIndex: 1,
            explanation: 'Una hora es insuficiente según la halajá ashkenazí.',
          },
          {
            id: '1b',
            questionId: '1',
            answerText: '3 horas',
            isCorrect: false,
            orderIndex: 2,
            explanation: 'Tres horas es la práctica sefardí, no ashkenazí.',
          },
          {
            id: '1c',
            questionId: '1',
            answerText: '6 horas',
            isCorrect: true,
            orderIndex: 3,
            explanation: 'Correcto. La tradición ashkenazí requiere 6 horas de espera.',
          },
        ],
        userAnswers: [],
      },
      {
        id: '2',
        topicId,
        questionText: '¿Qué significa que un alimento sea "Parve"?',
        explanation: 'Parve se refiere a alimentos que no son ni cárnicos ni lácteos, como frutas, verduras, huevos y pescado, y pueden comerse con cualquier comida.',
        difficulty: 1,
        orderIndex: 2,
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date(),
        answers: [
          {
            id: '2a',
            questionId: '2',
            answerText: 'Es un alimento prohibido',
            isCorrect: false,
            orderIndex: 1,
            explanation: 'Incorrecto. Parve no significa prohibido.',
          },
          {
            id: '2b',
            questionId: '2',
            answerText: 'Es neutro, ni cárnico ni lácteo',
            isCorrect: true,
            orderIndex: 2,
            explanation: 'Correcto. Parve significa neutro y puede comerse con cualquier comida.',
          },
          {
            id: '2c',
            questionId: '2',
            answerText: 'Es un alimento lácteo',
            isCorrect: false,
            orderIndex: 3,
            explanation: 'Incorrecto. Los alimentos lácteos se llaman "milchig".',
          },
        ],
        userAnswers: [],
      },
    ],
    _count: { questions: 20 }
  };

  const mockProgress: UserProgress = {
    topicId,
    topic: mockTopic,
    isCompleted: false,
    bestScore: 0,
    attemptsCount: 0,
    isUnlocked: true,
  };

  const mockAttempts = [
    {
      id: '1',
      score: 75,
      completedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      timeSpent: 420,
    },
    {
      id: '2',
      score: 85,
      completedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      timeSpent: 380,
    },
  ];

  useEffect(() => {
    // Simular carga de datos
    setTimeout(() => {
      setTopic(mockTopic);
      setUserProgress(mockProgress);
      setPreviousAttempts(mockAttempts);
      setLoading(false);
    }, 1000);
  }, [topicId]);

  const handleStartQuiz = () => {
    setShowQuiz(true);
  };

  const handleQuizComplete = async (result: QuizResult) => {
    // Actualizar progreso del usuario
    setUserProgress(prev => prev ? {
      ...prev,
      bestScore: Math.max(prev.bestScore, result.score),
      attemptsCount: prev.attemptsCount + 1,
      isCompleted: result.passed,
    } : null);

    // Agregar nuevo intento
    setPreviousAttempts(prev => [{
      id: Date.now().toString(),
      score: result.score,
      completedAt: new Date(),
      timeSpent: result.timeSpent,
    }, ...prev]);

    setShowQuiz(false);
  };

  const handleExitQuiz = () => {
    setShowQuiz(false);
  };

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const formatDate = (date: Date): string => {
    return date.toLocaleDateString('es-ES', {
      day: 'numeric',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-tallit-white via-white to-blue-50/30 flex items-center justify-center">
        <div className="text-center">
          <BookOpen className="h-12 w-12 text-tekhelet-600 animate-pulse mx-auto mb-4" />
          <p className="text-gray-600">Cargando tema...</p>
        </div>
      </div>
    );
  }

  if (!topic) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-tallit-white via-white to-blue-50/30 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Tema no encontrado</h2>
          <p className="text-gray-600 mb-4">El tema solicitado no existe o no está disponible.</p>
          <Button onClick={() => router.push('/estudiar')}>
            Volver a Estudios
          </Button>
        </div>
      </div>
    );
  }

  // Si está mostrando el quiz
  if (showQuiz) {
    return (
      <QuizComponent 
        topic={topic}
        onComplete={handleQuizComplete}
        onExit={handleExitQuiz}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-tallit-white via-white to-blue-50/30">
      <div className="container mx-auto px-4 py-8">
        {/* Navegación */}
        <div className="mb-6">
          <Button 
            variant="ghost" 
            onClick={() => router.push('/estudiar')}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Volver a Estudios
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Columna principal */}
          <div className="lg:col-span-2 space-y-6">
            {/* Información del tema */}
            <Card variant="featured">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-3">
                      <span className="px-3 py-1 text-sm font-medium bg-tekhelet-100 text-tekhelet-700 rounded-full">
                        Nivel {topic.level}
                      </span>
                      {userProgress?.isCompleted && (
                        <div className="flex items-center space-x-1 px-3 py-1 bg-green-100 text-green-700 rounded-full">
                          <CheckCircle className="h-4 w-4" />
                          <span className="text-sm font-medium">Completado</span>
                        </div>
                      )}
                    </div>
                    
                    <CardTitle className="text-2xl mb-2">
                      {topic.title}
                    </CardTitle>
                    
                    <div className="text-lg hebrew text-tekhelet-600 mb-4">
                      {topic.titleHebrew}
                    </div>
                    
                    <CardDescription className="text-base leading-relaxed">
                      {topic.description}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-tekhelet-600">
                      {topic._count?.questions || 0}
                    </div>
                    <div className="text-sm text-gray-600">Preguntas</div>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gold-accent-600">
                      {topic.requiredScore}%
                    </div>
                    <div className="text-sm text-gray-600">Para aprobar</div>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">
                      {userProgress?.attemptsCount || 0}
                    </div>
                    <div className="text-sm text-gray-600">Intentos</div>
                  </div>
                  
                  <div className="text-center">
                    <div className={cn(
                      "text-2xl font-bold",
                      (userProgress?.bestScore || 0) >= topic.requiredScore ? "text-green-600" : "text-gray-600"
                    )}>
                      {userProgress?.bestScore || 0}%
                    </div>
                    <div className="text-sm text-gray-600">Mejor puntuación</div>
                  </div>
                </div>

                <div className="flex justify-center">
                  <Button 
                    size="lg" 
                    variant="orthodox"
                    onClick={handleStartQuiz}
                    className="px-8"
                  >
                    <Play className="h-5 w-5 mr-2" />
                    {userProgress?.attemptsCount ? 'Repetir Quiz' : 'Comenzar Quiz'}
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Historial de intentos */}
            {previousAttempts.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <BarChart3 className="h-5 w-5" />
                    <span>Historial de Intentos</span>
                  </CardTitle>
                  <CardDescription>
                    Revisa tu progreso en este tema
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {previousAttempts.map((attempt, index) => (
                      <div 
                        key={attempt.id}
                        className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                      >
                        <div className="flex items-center space-x-4">
                          <div className="h-10 w-10 bg-tekhelet-100 rounded-full flex items-center justify-center">
                            <span className="text-sm font-medium text-tekhelet-700">
                              #{previousAttempts.length - index}
                            </span>
                          </div>
                          <div>
                            <div className="font-medium">
                              {formatDate(attempt.completedAt)}
                            </div>
                            <div className="text-sm text-gray-600">
                              Tiempo: {formatTime(attempt.timeSpent)}
                            </div>
                          </div>
                        </div>
                        
                        <div className="text-right">
                          <div className={cn(
                            "text-lg font-bold",
                            attempt.score >= topic.requiredScore ? "text-green-600" : "text-orange-600"
                          )}>
                            {attempt.score}%
                          </div>
                          <div className="text-xs text-gray-500">
                            {attempt.score >= topic.requiredScore ? 'Aprobado' : 'No aprobado'}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Progreso del usuario */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Trophy className="h-5 w-5 text-gold-accent-600" />
                  <span>Tu Progreso</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <div className="text-3xl font-bold text-tekhelet-600 mb-2">
                    {userProgress?.bestScore || 0}%
                  </div>
                  <div className="text-sm text-gray-600">Mejor puntuación</div>
                </div>

                {userProgress?.isCompleted ? (
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-center">
                    <CheckCircle className="h-8 w-8 text-green-600 mx-auto mb-2" />
                    <div className="text-green-800 font-medium">¡Tema Completado!</div>
                    <div className="text-green-600 text-sm">
                      Puedes repetirlo para mejorar tu puntuación
                    </div>
                  </div>
                ) : (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <Target className="h-6 w-6 text-blue-600 mb-2" />
                    <div className="text-blue-800 text-sm">
                      <strong>Objetivo:</strong> Obtener {topic.requiredScore}% para completar el tema
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Consejos para el quiz */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Star className="h-5 w-5 text-gold-accent-600" />
                  <span>Consejos</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm space-y-3">
                <div className="flex items-start space-x-2">
                  <Clock className="h-4 w-4 text-blue-600 mt-0.5" />
                  <div>
                    <strong>Tómate tu tiempo:</strong> No hay límite de tiempo, reflexiona bien cada respuesta.
                  </div>
                </div>
                
                <div className="flex items-start space-x-2">
                  <BookOpen className="h-4 w-4 text-green-600 mt-0.5" />
                  <div>
                    <strong>Lee las explicaciones:</strong> Cada pregunta incluye una explicación detallada.
                  </div>
                </div>
                
                <div className="flex items-start space-x-2">
                  <Award className="h-4 w-4 text-purple-600 mt-0.5" />
                  <div>
                    <strong>Practica:</strong> Puedes repetir el quiz tantas veces como quieras.
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Temas relacionados */}
            <Card>
              <CardHeader>
                <CardTitle>Temas Relacionados</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button variant="outline" className="w-full justify-start">
                  <BookOpen className="h-4 w-4 mr-2" />
                  Introducción a la Halajá
                </Button>
                
                <Button variant="outline" className="w-full justify-start">
                  <BookOpen className="h-4 w-4 mr-2" />
                  Shabat - Preparación
                </Button>
                
                <Button variant="outline" className="w-full justify-start">
                  <BookOpen className="h-4 w-4 mr-2" />
                  Tefilá Diaria
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}