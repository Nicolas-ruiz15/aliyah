'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { 
  BookOpen, 
  Lock, 
  CheckCircle, 
  Star, 
  Clock,
  Trophy,
  Target,
  Play,
  BarChart3,
  Filter,
  Search,
  Award
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Progress } from '../../components/ui/progress';
import { useAuth } from '../../components/providers/AuthProvider';
import { useToast } from '../../components/providers/ToastProvider';
import { cn } from '../../lib/utils';
import type { QuizTopicWithQuestions, UserProgress } from '../../types/global';

export default function EstudiarPage() {
  const [topics, setTopics] = useState<QuizTopicWithQuestions[]>([]);
  const [userProgress, setUserProgress] = useState<UserProgress[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedLevel, setSelectedLevel] = useState<number | null>(null);
  const { user } = useAuth();
  const { toast } = useToast();

  // Mock data - en la implementación real vendría de la API
  const mockTopics: QuizTopicWithQuestions[] = [
    {
      id: '1',
      title: 'Introducción a la Halajá',
      titleHebrew: 'מבוא להלכה',
      description: 'Conceptos fundamentales de la ley judía y su aplicación diaria',
      level: 1,
      orderIndex: 1,
      isActive: true,
      requiredScore: 80,
      questions: [],
      createdAt: new Date(),
      updatedAt: new Date(),
      _count: { questions: 15 }
    },
    {
      id: '2',
      title: 'Kashrut Básico',
      titleHebrew: 'כשרות בסיסית',
      description: 'Leyes dietéticas judías: carnes, productos lácteos y separación',
      level: 1,
      orderIndex: 2,
      isActive: true,
      requiredScore: 80,
      questions: [],
      createdAt: new Date(),
      updatedAt: new Date(),
      _count: { questions: 20 }
    },
    {
      id: '3',
      title: 'Shabat - Preparación',
      titleHebrew: 'שבת - הכנות',
      description: 'Preparativos para el Shabat: velas, jalá, vino y mesa festiva',
      level: 2,
      orderIndex: 3,
      isActive: true,
      requiredScore: 80,
      questions: [],
      createdAt: new Date(),
      updatedAt: new Date(),
      _count: { questions: 25 }
    },
    {
      id: '4',
      title: 'Tefilá Diaria',
      titleHebrew: 'תפילה יומית',
      description: 'Oraciones diarias: Shajarit, Minjá y Maariv',
      level: 2,
      orderIndex: 4,
      isActive: true,
      requiredScore: 85,
      questions: [],
      createdAt: new Date(),
      updatedAt: new Date(),
      _count: { questions: 30 }
    },
    {
      id: '5',
      title: 'Festividades Judías',
      titleHebrew: 'חגי ישראל',
      description: 'Leyes y costumbres de Rosh Hashaná, Yom Kipur y Sucot',
      level: 3,
      orderIndex: 5,
      isActive: true,
      requiredScore: 85,
      questions: [],
      createdAt: new Date(),
      updatedAt: new Date(),
      _count: { questions: 35 }
    },
    {
      id: '6',
      title: 'Matrimonio Judío',
      titleHebrew: 'נישואין יהודיים',
      description: 'Leyes del matrimonio, nidá y vida familiar judía',
      level: 3,
      orderIndex: 6,
      isActive: true,
      requiredScore: 90,
      questions: [],
      createdAt: new Date(),
      updatedAt: new Date(),
      _count: { questions: 40 }
    },
  ];

  // Cambia la definición de mockProgress por esto:

// Reemplaza mockProgress con esto:

const mockProgress: UserProgress[] = [
  {
    topicId: mockTopics[0]!.id,
    topic: mockTopics[0]!,
    isCompleted: true,
    bestScore: 95,
    attemptsCount: 2,
    isUnlocked: true,
  },
  {
    topicId: mockTopics[1]!.id,
    topic: mockTopics[1]!,
    isCompleted: true,
    bestScore: 88,
    attemptsCount: 1,
    isUnlocked: true,
  },
  {
    topicId: mockTopics[2]!.id,
    topic: mockTopics[2]!,
    isCompleted: false,
    bestScore: 0,
    attemptsCount: 0,
    isUnlocked: true,
  },
  {
    topicId: mockTopics[3]!.id,
    topic: mockTopics[3]!,
    isCompleted: false,
    bestScore: 0,
    attemptsCount: 0,
    isUnlocked: false,
  },
  {
    topicId: mockTopics[4]!.id,
    topic: mockTopics[4]!,
    isCompleted: false,
    bestScore: 0,
    attemptsCount: 0,
    isUnlocked: false,
  },
  {
    topicId: mockTopics[5]!.id,
    topic: mockTopics[5]!,
    isCompleted: false,
    bestScore: 0,
    attemptsCount: 0,
    isUnlocked: false,
  },
];
  useEffect(() => {
    // Simular carga de datos
    setTimeout(() => {
      setTopics(mockTopics);
      setUserProgress(mockProgress);
      setLoading(false);
    }, 1000);
  }, []);

  // Filtrar temas
  const filteredTopics = topics.filter(topic => {
    const matchesSearch = topic.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         topic.titleHebrew?.includes(searchTerm) ||
                         topic.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesLevel = selectedLevel === null || topic.level === selectedLevel;
    
    return matchesSearch && matchesLevel;
  });

  // Estadísticas del usuario
  const completedTopics = userProgress.filter(p => p.isCompleted).length;
  const totalScore = userProgress.reduce((sum, p) => sum + p.bestScore, 0);
  const averageScore = completedTopics > 0 ? Math.round(totalScore / completedTopics) : 0;
  const unlockedTopics = userProgress.filter(p => p.isUnlocked).length;

  const getLevelColor = (level: number): string => {
    const colors = {
      1: 'text-green-600 bg-green-100',
      2: 'text-blue-600 bg-blue-100',
      3: 'text-purple-600 bg-purple-100',
      4: 'text-red-600 bg-red-100',
    };
    return colors[level as keyof typeof colors] || 'text-gray-600 bg-gray-100';
  };

  const getLevelName = (level: number): string => {
    const names = {
      1: 'Básico',
      2: 'Intermedio',
      3: 'Avanzado',
      4: 'Experto',
    };
    return names[level as keyof typeof names] || 'Desconocido';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-tallit-white via-white to-blue-50/30 flex items-center justify-center">
        <div className="text-center">
          <BookOpen className="h-12 w-12 text-tekhelet-600 animate-pulse mx-auto mb-4" />
          <p className="text-gray-600">Cargando contenido educativo...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-tallit-white via-white to-blue-50/30">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                Educación Halájica
              </h1>
              <p className="text-gray-600">
                Aprende y certifica tu conocimiento de la ley judía
              </p>
              <p className="text-sm hebrew text-tekhelet-700 mt-1">
                למד והסמך את הידע שלך בהלכה יהודית
              </p>
            </div>
            <div className="text-right">
              <div className="text-sm text-gray-500">Tu progreso</div>
              <div className="text-2xl font-bold text-tekhelet-700">
                {completedTopics}/{topics.length}
              </div>
            </div>
          </div>

          {/* Estadísticas */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <Card variant="orthodox">
              <CardContent className="p-4 text-center">
                <Trophy className="h-8 w-8 text-gold-accent-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">{completedTopics}</div>
                <div className="text-xs text-gray-600">Completados</div>
              </CardContent>
            </Card>

            <Card variant="orthodox">
              <CardContent className="p-4 text-center">
                <Target className="h-8 w-8 text-green-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">{averageScore}%</div>
                <div className="text-xs text-gray-600">Promedio</div>
              </CardContent>
            </Card>

            <Card variant="orthodox">
              <CardContent className="p-4 text-center">
                <BookOpen className="h-8 w-8 text-tekhelet-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">{unlockedTopics}</div>
                <div className="text-xs text-gray-600">Disponibles</div>
              </CardContent>
            </Card>

            <Card variant="orthodox">
              <CardContent className="p-4 text-center">
                <Award className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">
                  {userProgress.filter(p => p.bestScore >= 90).length}
                </div>
                <div className="text-xs text-gray-600">Excelencia</div>
              </CardContent>
            </Card>
          </div>

          {/* Progreso general */}
          <Card variant="featured" className="mb-6">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Progreso General</h3>
                <span className="text-sm text-gray-600">
                  {Math.round((completedTopics / topics.length) * 100)}% Completado
                </span>
              </div>
              <Progress value={(completedTopics / topics.length) * 100} className="h-3" />
            </CardContent>
          </Card>
        </div>

        {/* Filtros */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1">
            <Input
              placeholder="Buscar temas..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              leftIcon={<Search className="h-4 w-4" />}
            />
          </div>
          
          <div className="flex gap-2">
            <Button
              variant={selectedLevel === null ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedLevel(null)}
            >
              Todos
            </Button>
            {[1, 2, 3, 4].map(level => (
              <Button
                key={level}
                variant={selectedLevel === level ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedLevel(level)}
              >
                Nivel {level}
              </Button>
            ))}
          </div>
        </div>

        {/* Lista de temas */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTopics.map((topic) => {
            const progress = userProgress.find(p => p.topicId === topic.id);
            const isUnlocked = progress?.isUnlocked || false;
            const isCompleted = progress?.isCompleted || false;
            const bestScore = progress?.bestScore || 0;
            const attempts = progress?.attemptsCount || 0;

            return (
              <Card 
                key={topic.id} 
                className={cn(
                  'transition-all duration-200 hover:scale-105',
                  isCompleted && 'border-green-200 bg-green-50/50',
                  !isUnlocked && 'opacity-60'
                )}
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <span className={cn(
                          'px-2 py-1 text-xs font-medium rounded-full',
                          getLevelColor(topic.level)
                        )}>
                          {getLevelName(topic.level)}
                        </span>
                        {isCompleted && (
                          <CheckCircle className="h-5 w-5 text-green-600" />
                        )}
                        {!isUnlocked && (
                          <Lock className="h-5 w-5 text-gray-400" />
                        )}
                      </div>
                      
                      <CardTitle className="text-lg leading-tight">
                        {topic.title}
                      </CardTitle>
                      
                      <div className="text-sm hebrew text-tekhelet-600 mt-1">
                        {topic.titleHebrew}
                      </div>
                    </div>
                  </div>
                  
                  <CardDescription className="text-sm">
                    {topic.description}
                  </CardDescription>
                </CardHeader>

                <CardContent>
                  <div className="space-y-4">
                    {/* Estadísticas del tema */}
                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div>
                        <div className="text-lg font-bold text-gray-900">
                          {topic._count?.questions || 0}
                        </div>
                        <div className="text-xs text-gray-600">Preguntas</div>
                      </div>
                      
                      <div>
                        <div className="text-lg font-bold text-gray-900">
                          {attempts}
                        </div>
                        <div className="text-xs text-gray-600">Intentos</div>
                      </div>
                      
                      <div>
                        <div className={cn(
                          'text-lg font-bold',
                          bestScore >= topic.requiredScore ? 'text-green-600' : 'text-gray-900'
                        )}>
                          {bestScore}%
                        </div>
                        <div className="text-xs text-gray-600">Mejor</div>
                      </div>
                    </div>

                    {/* Progreso individual */}
                    {isCompleted && (
                      <div className="bg-green-100 rounded-lg p-3">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-green-800 font-medium">¡Completado!</span>
                          <div className="flex items-center space-x-1">
                            <Star className="h-4 w-4 text-green-600" />
                            <span className="text-green-700">{bestScore}%</span>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Botón de acción */}
                    <div className="pt-2">
                      {isUnlocked ? (
                        <Link href={`/estudiar/${topic.id}`}>
                          <Button 
                            variant={isCompleted ? "outline" : "orthodox"} 
                            className="w-full"
                          >
                            <Play className="h-4 w-4 mr-2" />
                            {isCompleted ? 'Repasar' : 'Comenzar'}
                          </Button>
                        </Link>
                      ) : (
                        <Button variant="outline" disabled className="w-full">
                          <Lock className="h-4 w-4 mr-2" />
                          Bloqueado
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* No hay resultados */}
        {filteredTopics.length === 0 && (
          <div className="text-center py-12">
            <BookOpen className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              No se encontraron temas
            </h3>
            <p className="text-gray-600">
              Intenta ajustar tus filtros de búsqueda
            </p>
          </div>
        )}

        {/* Información adicional */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <BarChart3 className="h-5 w-5 text-tekhelet-600" />
                <span>Cómo Funciona</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="text-sm space-y-2">
              <p>• Completa los temas en orden para desbloquear nuevos niveles</p>
              <p>• Necesitas {topics[0]?.requiredScore || 80}% para aprobar cada tema</p>
              <p>• Puedes repetir los quizzes para mejorar tu puntuación</p>
              <p>• Obtén certificados al completar módulos completos</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Award className="h-5 w-5 text-gold-accent-600" />
                <span>Beneficios</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="text-sm space-y-2">
              <p>• Certifica tu conocimiento halájico</p>
              <p>• Prepárate mejor para la vida en Israel</p>
              <p>• Obtén reconocimiento de instituciones ortodoxas</p>
              <p>• Fortalece tu identidad judía</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}